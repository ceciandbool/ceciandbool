# DOM Tree

Happy holidays! I didn't get a pine tree for Christmas this year so I decided to compensate by creating a digital counterpart out of HTML form elements.

[Check out the live demo](http://hakim.se/experiments/css/domtree).

# License

MIT licensed

Copyright (C) 2017 Hakim El Hattab, http://hakim.se